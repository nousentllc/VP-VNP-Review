# An Audit of the Lean Formalization of VP ≠ VNP over Every Field

Justin Candler · November 26, 2026 · version 1.1

[Report v1.1](https://doi.org/10.5281/zenodo.24572841) · [Report v1.0](https://doi.org/10.5281/zenodo.24568943) · [Software companion](https://doi.org/10.5281/zenodo.24569000) · [Release notes](RELEASE_NOTES.md)

## Release files

[Read the 81-page PDF](VP_VNP_Audit_and_Dossier_v1.1.pdf) · [Edit the manuscript](VP_VNP_Audit_and_Dossier_v1.1.tex) · [Manuscript verification](evidence/manuscript-verification.json) · [Review the TeX changes from v1.0](evidence/manuscript-changes.diff)

## Changes from v1.0

- The derivation for C.1 now divides the slope inequality by the amplitude times the mesh parameter once and displays the finite error explicitly. Taking the amplitude to infinity at fixed scale, then taking the scale to infinity, suffices. An amplitude equal to the square of the scale also works because the squared norm in the intercept has a uniform bound. Setting the two scales equal gives no uniform decay of that term from the displayed estimate.
- The endpoint summary gives the field restriction for each polynomial. The exact and Laurent-series approximation bounds for Hamiltonian cycles apply over every field. The permanent clauses apply over fields of characteristic other than two.
- The J.4 account specifies the scale and exponent hypotheses for the common cutter and the K.5 arithmetic. The sharper listing and traversal estimates concern two cost terms of the construction. The final separation exponent retains its published value.
- The manuscript records which checks the review team repeated on November 26. The complete Edition 12 claim dossier carries its original historical dispositions.

## Rebuild the manuscript

Use LuaLaTeX from TeX Live with Latin Modern OpenType fonts and the packages in the preamble, including PGF/TikZ, xurl, and needspace. Place the supplied TeX source and original `nous-black.png` in the same directory. Run `sh build.sh` from the extracted package. The script uses a local font cache, a fixed timestamp and three LuaLaTeX passes with shell escape disabled. The supplied checksum manifest identifies the output tested with TeX Live 2026. Other TeX and font versions may change line breaks or file bytes.

The revised C.1 normalization has an exact-rational control covering 5,664 scalar configurations, including 480 with zero endpoint radius. Its input assumptions and one-length counterexample are recorded alongside the program. [C.1 derivation and replay](evidence/c1-remainder/README.md)

## Verification evidence

Three Tier 0 runs checked the same 24 finite controls, the 333-blob publisher tree, 47 historical items and the 63-entry claim map on three inputs. Those inputs were review main at `f7d16f5fd48ac0ffcfe50c3828778dc7c97a27c3`, the review tag at `f726d3a7608e31b5c88804764b6e65c203179d42`, and the extracted v1.0 software deposit. A separate native Lean 4.33.1 replay elaborated the two J.4 declarations on retained publisher objects. The original historical transcript, hashes, and the three permitted axioms matched in the recorded fields. [Replay instructions and receipts](evidence/receipts/REPLAY.md) · [Machine-readable replay details](evidence/receipts/fresh-checks.json)

The earlier native build covered 324 publisher Lean source files. The original review-team Linux run built the four publisher targets and accepted all five configured declarations in Lean and nanoda. The 23-module native Tier 1 check and the Tier 2 archive verifier have their own historical records. The full Linux run was launched by the review team. Claude Opus 5.5 reported an external AI Tier 0 replay. Its contribution and the editorial readers are credited in the original disclosure. [Hosted Linux run](https://github.com/nousentllc/VP-VNP-Review/actions/runs/45691617731/job/139478246305) · [External AI reviews](EXTERNAL_AI_REVIEWS.md)

The original evidence companion in this package has SHA-256 `38ef8c5b8484b46323896d15886c5ef90c96c07573767a0b86dfc34d06bb1442`. Unpack it to read the publisher source and notices, pin manifest, claim register, J.4 source, reproduction instructions and full historical evidence in their original layout. Its 530 selected evidence files matched the v1.0 report archive and the reviewed main snapshot. Historical release notes retain the status at the time they were written. [Deposited source ZIP](evidence/VP_VNP_Reproducibility_Source_v1.0.zip) · [File comparison](evidence/receipts/source-crosscheck.json)

The supplementary publication examples were rerun from the pinned main snapshot. They give 392 orthogonality cases, 1,012 modular counter cases and 72 integer J.4 cases, alongside the two exact rational checks. To reproduce, run `python3 -B verify_examples.py` in `evidence/publication-examples/` and compare stdout with `finite-examples.json`. [Program](evidence/publication-examples/verify_examples.py) · [Expected output](evidence/publication-examples/finite-examples.json) · [Replay receipt](evidence/publication-examples/replay.json)

## Open review and archive items

The review team is still seeking a named human assessment of statement correspondence and an outside operator's Tier 1/2 transcripts. The release-candidate Docker entry points await a fresh Linux replay in the public record. The upstream suggestions for K.3 and I.1 await a publisher response. The public Zenodo software record had no confirmed Software Heritage identifier at this check. [Statement review request](https://github.com/nousentllc/VP-VNP-Review/issues/1) · [Upstream wording request](https://github.com/anthropics/formal-math/issues/57) · [Public records and checked pins](evidence/public-records.json)

The review prose and report are available under CC BY 4.0, and the review software under MIT. The publisher retains its Apache-2.0 license and notice. Other third-party rights, including the logo, follow their respective terms. [License scope](LICENSES/README.md) · [Publisher notice](primary/vp-vnp/NOTICE)

The public-records JSON and kernel receipts under evidence retain the dates and statuses of the original checks. The release notes give the remaining independent-review obligations.
