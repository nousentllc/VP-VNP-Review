# C.1 finite error bound

This supplemental check starts at the scalar slope comparison in Pass 9. The previously archived Lean development supplies the formal endpoint for price geometry. This supplement checks a finite algebraic consequence and two choices of comparison length in the report's exposition. All sampled arithmetic uses exact rational numbers.

Write $T\ge2$, $A\ge1$, $\theta=1/T$, $H=D+b$ and $C=6D^2+6Db+b^2$, with $D,b\ge0$. The fan estimates give $p\ge D^2$, $0\le q\le Q=D^2(1-\theta+\theta^2)$, and $0\le\Lambda_2\le H^2$. The finite slope comparison is

$$
A[\theta\Gamma-4\theta^2DH-(q-p+\theta^2\Lambda_2)]\le q .
$$

Dividing once by $A\theta$ and adding $D^2$ bounds $\Gamma+D^2$. The difference between $q/(A\theta)+\theta C$ and this upper bound is exactly

$$
\frac{Q-q+p-D^2}{\theta}+\theta(H^2-\Lambda_2)\ge0 .
$$

Since $q\le D^2$, a uniform remainder is $D^2T/A+C/T$. The proof may first send $A$ to infinity at fixed $T$ and then send $T$ to infinity. Alternatively, any integer sequence with $T\to\infty$ and $A/T\to\infty$ makes both terms vanish. For $A=T^2$ the bound is $(D^2+C)/T$. For $A=T$, the intercept is $q$. At $D=1,b=0,q=1-1/T+1/T^2$, the scalar constraints permit $q\ge3/4$ at every mesh. This shows why the bound alone supplies no decay for that choice and makes no assertion that a geometric fan realizes those scalar inputs. If $D=0$, the constraints give $q=0$, and the remainder reduces to $b^2/T$.

The program tests the slack identity and both inequalities on 5,664 scalar configurations, including 480 with $D=0$. These include 48 with $D=b=0$. An additional one-length test with $T=4,A=1,D=1,b=0$ attains $19/4$ for the upper bound on $\Gamma+D^2$, while the mesh term alone is $3/2$. The upper value comes from saturating that single finite scalar constraint. The all-length premise in the geometric proof is stronger.

Run `python3 check_c1_remainder.py` and compare its standard output with `results.json`. No external packages are required.

The fixed source anchors are the [Pass 9 derivation](https://github.com/nousentllc/VP-VNP-Review/blob/567303d0bcf4f9d54390437b137752446e58ccd6/passes/09-curvature-bound.md#L41-L59), [the archived scalar Lean argument](https://github.com/nousentllc/VP-VNP-Review/blob/567303d0bcf4f9d54390437b137752446e58ccd6/checks/pass09_endpoint.lean#L41-L68) and [the publisher's C.1 endpoint](https://github.com/anthropics/formal-math/blob/11b6c7e3c927df2658f513b6b68ea7f8929c62c5/vp-vnp/Paper/Fan.lean#L929-L987).
