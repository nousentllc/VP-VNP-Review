"""Check the finite scalar implication used to explain the C.1 endpoint."""
from fractions import Fraction as F
from itertools import product
import json


def require(condition, description):
    if not condition:
        raise ArithmeticError(description)


def compare_bounds(d, b, t, a, p, q, moment):
    theta = F(1, t)
    h = d + b
    q_cap = d**2 * (1 - theta + theta**2)
    coefficient = 6*d**2 + 6*d*b + b**2
    require(d >= 0 and b >= 0 and t >= 2 and a >= 1, "invalid parameters")
    require(p >= d**2 and 0 <= q <= q_cap and 0 <= moment <= h**2, "invalid scalar premise")

    # Solve the finite slope comparison for Gamma, saturating its inequality.
    gamma_max = q/(a*theta) + (q-p)/theta + theta*moment + 4*theta*d*h
    recovered_lhs = a * (theta*gamma_max - 4*theta**2*d*h - (q-p+theta**2*moment))
    require(recovered_lhs == q, "the unnormalized slope comparison")
    finite_max = gamma_max + d**2
    sharp_bound = q/(a*theta) + theta*coefficient
    slack = (q_cap-q + p-d**2)/theta + theta*(h**2-moment)
    require(sharp_bound - finite_max == slack >= 0, "exact finite slack decomposition")

    envelope = d**2 * t/a + coefficient/t
    require(envelope - sharp_bound == (d**2-q)/(a*theta) >= 0, "uniform intercept bound")
    return finite_max, sharp_bound, envelope


def run():
    distances = (F(0), F(1,3), F(1), F(5,2))
    meshes = (2, 3, 4, 7, 16, 32)
    fractions = (F(0), F(1,2), F(1))
    total = zero_d = zero_d_and_b = 0
    for d, b, t in product(distances, distances, meshes):
        h, theta = d+b, F(1,t)
        q_cap = d**2 * (1-theta+theta**2)
        for a, excess, q, moment in product(sorted({1, t, t+1, t*t}), (F(0), F(2,3)),
                                             sorted({f*q_cap for f in fractions}),
                                             sorted({f*h**2 for f in fractions})):
            compare_bounds(d, b, t, a, d**2+excess, q, moment)
            total += 1
            zero_d += int(d == 0)
            zero_d_and_b += int(d == 0 and b == 0)

    # D=1, b=0 and q at its scalar cap. These are scalar controls; a price
    # realizing these data is neither needed nor asserted.
    examples = []
    for t in (2, 4, 8, 16, 64):
        theta = F(1, t)
        q = 1-theta+theta**2
        intercept_linear = q/(t*theta)
        intercept_quadratic = q/(t*t*theta)
        require(intercept_linear == q and intercept_linear >= F(3,4), "linear diagonal intercept")
        require(intercept_quadratic == q/t <= F(1,t), "quadratic diagonal intercept")
        _, _, linear = compare_bounds(F(1), F(0), t, t, F(1), q, F(1))
        _, _, quadratic = compare_bounds(F(1), F(0), t, t*t, F(1), q, F(1))
        require(linear == 1 + F(6,t) and quadratic == F(7,t), "diagonal envelopes")
        examples.append(dict(T=t, intercept_A_equals_T=str(intercept_linear),
                             intercept_A_equals_T_squared=str(intercept_quadratic),
                             envelope_A_equals_T=str(linear), envelope_A_equals_T_squared=str(quadratic)))

    # At one finite A the intercept cannot simply be dropped. Saturating
    # the one-A scalar inequality need not give common fan data for every A.
    t = 4
    finite, sharp, _ = compare_bounds(F(1), F(0), t, 1, F(1), F(13,16), F(1))
    require(finite == sharp == F(19,4) > F(6,t), "omitted-intercept control")
    return dict(scope="Exact finite scalar controls conditional on the C.1 slope and fan bounds.",
                arithmetic="Python standard library fractions.Fraction",
                scalar_configurations=total, zero_distance_D_cases=zero_d,
                both_D_and_b_zero_cases=zero_d_and_b, diagonal_controls=examples,
                omitted_intercept_control=dict(D=1,b=0,T=t,A=1,p="1",q="13/16",Lambda="1",
                                              finite_maximum=str(finite),mesh_term_alone=str(F(6,t))),
                status="passed")


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
