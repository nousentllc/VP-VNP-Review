"""Finite checks of algebraic interfaces in Anthropic Appendix C.
Not a formal proof, not a check of spectral realizability. Python stdlib only.
Run python pass08_checks.py > pass08_checks.json
"""
from fractions import Fraction as F
from itertools import product
import json

def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
def sub(a,b):return add(a,neg(b))
def scale(a,k):return tuple(k*x for x in a)

def main():
    # Verify the exact telescoping identity before using the price-specific inequality.
    # L1 and L-infinity are arbitrary seminorms here, not assumed prices.
    vectors=list(product(range(-2,3),repeat=2));m=9;count=0
    for norm in (lambda x:sum(abs(y) for y in x),lambda x:max(abs(y) for y in x),lambda x:abs(2*x[0]-x[1])):
        for a,b in product(vectors,repeat=2):
            c,e=add(a,b),sub(a,b)
            def A(i):return add(scale(c,m),scale(e,i))
            def delta(i):return norm(sub(A(i),a))-norm(sub(A(i),scale(a,2)))
            def partial(p):return 2*norm(p)-norm(sub(p,a))-norm(sub(p,b))
            for i in range(3):
                p=A(i)
                assert partial(p)+partial(sub(p,a))==2*(norm(p)-norm(sub(p,c)))+delta(i)-delta(i+1)
                count+=1
    # C.1(iv): verify the explicit uniform remainder in the squared pointwise step.
    # Bound is valid for arbitrary nonnegative lengths with the specified Lipschitz/rho constraints.
    step=0
    for D in (F(0),F(1),F(3,2)):
        for M in (D,D+1,D+4):
            for n,S,A,T in product((3,5,9),(1,2),(1,3),(2,3,7)):
                if n<A*S:continue
                theta=F(1,T)
                for L in (F(0),M/2,M):
                    for drift in (-D*S/n**2,F(0),D*S/n**2):
                        Lp=L+drift
                        if not 0<=Lp<=M:continue
                        for rho in (1-2*theta,1-theta, F(1)):
                            left=(n*n*rho*(Lp-L)+A*S*theta*Lp)**2
                            right=A*A*S*S*theta**2*Lp**2 + A*S*theta*n*n*(Lp**2-L**2)-4*A*S*S*theta**2*D*M
                            assert left>=right,(D,M,n,S,A,T,L,Lp,rho)
                            step+=1
    # Finite tests of C.1 conclusion in Euclidean plane (equality), including zero D.
    euc=0
    for u,v,z in product(vectors,repeat=3):
        sq=lambda x:sum(y*y for y in x)
        mid=tuple(F(x+y,2) for x,y in zip(u,v))
        assert sq(sub(z,mid))==F(1,2)*(sq(sub(z,u))+sq(sub(z,v)))-F(1,4)*sq(sub(u,v))
        euc+=1
    # An arbitrary metric with midpoints need not have CN: l1 unit square configuration.
    u=(-1,0);v=(1,0);mid=(0,0);z=(0,1)
    # Use l-infinity instead: distances to endpoints both 1, dist to midpoint 1 => RHS 0.
    norm=lambda x:max(abs(y) for y in x)
    lhs=norm(sub(z,mid))**2;rhs=F(1,2)*(norm(sub(z,u))**2+norm(sub(z,v))**2)-F(1,4)*norm(sub(u,v))**2
    assert lhs>rhs
    print(json.dumps({'C2_telescope_identities':count,'C1iv_exact_rational_inequality_checks':step,'euclidean_CN_equalities':euc,'arbitrary_metric_counterexample':{'metric':'l_infinity','x':u,'v':v,'m':mid,'z':z,'lhs':str(lhs),'rhs':str(rhs)},'limitations':'These finite checks validate algebraic subidentities under chosen hypotheses; they do not prove B.2, A.5, spectral realizability, or any general separation theorem.'},indent=2))
if __name__=='__main__':main()
