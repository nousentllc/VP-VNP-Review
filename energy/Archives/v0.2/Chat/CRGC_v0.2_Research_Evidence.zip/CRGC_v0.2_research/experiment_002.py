"""CRGC Experiment 002: exact aggregate interface for a homogeneous flexible
bank plus a separate protected reserve fleet. Synthetic integer model only.
Run: python experiment_002.py > experiment_002_results.json
Requires Python 3.10+, scipy, numpy. Seeded, reproducible objective/count results;
wall-clock values are machine-dependent. All interval lengths = one model unit.
"""
from itertools import product
from functools import lru_cache
from time import perf_counter
import random, json, platform
import numpy as np
import scipy
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

C,R,CR,RR=4,1,3,1
GMAX,RAMP,INIT_G=9,2,5
FLEX_CYCLE,RES_CYCLE=1,3

def balanced(total,n):
    return tuple((total+i)//n for i in range(n))

@lru_cache(None)
def transitions(z,mode,n):
    if mode=='aggregate':
        return tuple((v,v-z,abs(v-z)) for v in range(max(0,z-n*R),min(n*C,z+n*R)+1))
    out={}
    for v in product(*(range(max(0,s-R),min(C,s+R)+1) for s in z)):
        change=sum(v)-sum(z)
        cost=sum(abs(a-b) for a,b in zip(v,z))
        k=tuple(sorted(v)) if mode=='quotient' else v
        if k not in out or cost<out[k][1]: out[k]=(change,cost)
    return tuple((k,d,c) for k,(d,c) in out.items())

def dp(case,mode):
    n,load,price,floor=case['n'],case['load'],case['price'],case['floor']
    z0=2*n if mode=='aggregate' else (2,)*n
    initial=(z0,2,INIT_G); values={initial:0}; parents=[]
    checks=0; expanded=0; peak=1
    t0=perf_counter()
    for t,(d,p,f) in enumerate(zip(load,price,floor)):
        new={}; par={}; expanded+=len(values)
        for (z,r,g0),value in values.items():
            # Local battery transitions; count checks after local bounds, before grid/ramp bounds.
            for zp,ds,cyc in transitions(z,mode,n):
                for rp in range(max(f,r-RR),min(CR,r+RR)+1):
                    checks+=1
                    g=d+ds+rp-r
                    if not (0<=g<=GMAX and abs(g-g0)<=RAMP): continue
                    cost=value+p*g+FLEX_CYCLE*cyc+RES_CYCLE*abs(rp-r)
                    k=(zp,rp,g)
                    if k not in new or cost<new[k]: new[k]=cost; par[k]=(z,r,g0)
        values=new; parents.append(par); peak=max(peak,len(values))
    feasible=[(v,k) for k,v in values.items() if k[:2]==(z0,2)]
    if not feasible: return {'cost':None,'checks':checks,'expanded':expanded,'peak':peak,'seconds':perf_counter()-t0}
    cost,k=min(feasible); path=[k]
    for p in reversed(parents): k=p[k]; path.append(k)
    path.reverse()
    if mode=='aggregate':
        lifted=[(balanced(z,n),r,g) for z,r,g in path]
        verify(case,lifted,cost)
    elif mode=='labeled': verify(case,path,cost)
    # quotient path can be relabeled stage-by-stage; not needed to establish aggregate lift.
    return {'cost':cost,'checks':checks,'expanded':expanded,'peak':peak,'seconds':perf_counter()-t0,
            'path':path}

def verify(case,path,expected):
    n=case['n']; assert path[0]==((2,)*n,2,INIT_G); assert path[-1][:2]==((2,)*n,2)
    c=0
    for t,((a,r,g0),(b,rp,g)) in enumerate(zip(path,path[1:])):
        assert len(b)==n and all(0<=s<=C for s in b) and all(abs(x-y)<=R for x,y in zip(a,b))
        assert case['floor'][t]<=rp<=CR and abs(rp-r)<=RR
        assert g==case['load'][t]+sum(b)-sum(a)+rp-r and 0<=g<=GMAX and abs(g-g0)<=RAMP
        c+=case['price'][t]*g+FLEX_CYCLE*sum(abs(x-y) for x,y in zip(a,b))+RES_CYCLE*abs(rp-r)
    assert c==expected,(c,expected)

def independent_milp(case):
    # Different formulation: individual battery SOC + separate charge/discharge,
    # and grid import. Positive cycling penalty excludes simultaneous charge/discharge
    # from an optimum. All variables integer, same capacity, ramps, objective, endpoints.
    n=case['n']; T=len(case['load']); banks=n+1
    caps=[C]*n+[CR]; rates=[R]*n+[RR]; wear=[FLEX_CYCLE]*n+[RES_CYCLE]
    V=(T+1)*banks+2*T*banks+T
    def s(t,i): return t*banks+i
    def ch(t,i): return (T+1)*banks+t*banks+i
    def ds(t,i): return (T+1)*banks+T*banks+t*banks+i
    def g(t): return (T+1)*banks+2*T*banks+t
    obj=np.zeros(V); lo=np.zeros(V); hi=np.zeros(V)
    for t in range(T+1):
        for i in range(banks):
            hi[s(t,i)]=caps[i]
            if i==n and t>0: lo[s(t,i)]=case['floor'][t-1]
            if t in (0,T): lo[s(t,i)]=hi[s(t,i)]=2
    for t in range(T):
        hi[g(t)]=GMAX; obj[g(t)]=case['price'][t]
        for i in range(banks):
            hi[ch(t,i)]=hi[ds(t,i)]=rates[i]; obj[ch(t,i)]=obj[ds(t,i)]=wear[i]
    rows=[]; cols=[]; data=[]; lbs=[]; ubs=[]
    def row(entries,lb,ub):
        j=len(lbs); lbs.append(lb); ubs.append(ub)
        for i,v in entries: rows.append(j); cols.append(i); data.append(v)
    for t in range(T):
        for i in range(banks):
            row([(s(t+1,i),1),(s(t,i),-1),(ch(t,i),-1),(ds(t,i),1)],0,0)
        row([(g(t),1)]+[(ch(t,i),-1) for i in range(banks)]+[(ds(t,i),1) for i in range(banks)],case['load'][t],case['load'][t])
        if t==0: row([(g(t),1)],INIT_G-RAMP,INIT_G+RAMP)
        else: row([(g(t),1),(g(t-1),-1)],-RAMP,RAMP)
    mat=coo_matrix((data,(rows,cols)),shape=(len(lbs),V)).tocsc()
    t0=perf_counter(); ans=milp(obj,integrality=np.ones(V),bounds=Bounds(lo,hi),constraints=LinearConstraint(mat,lbs,ubs),options={'mip_rel_gap':0.,'time_limit':30.})
    result={'status':int(ans.status),'message':str(ans.message),'cost':None if ans.fun is None else float(ans.fun),'dual_bound':None if getattr(ans,'mip_dual_bound',None) is None else float(ans.mip_dual_bound),'gap':None if getattr(ans,'mip_gap',None) is None else float(ans.mip_gap),'seconds':perf_counter()-t0}
    assert ans.status in (0,2),result
    return result

def generate():
    rng=random.Random(20261124)
    for n in (2,3):
        for i in range(12):
            T=10 if i<6 else 14
            load=[rng.randint(3,7) for _ in range(T)]
            price=[rng.randint(1,12) for _ in range(T)]
            floor=[3 if t in (3,4,7) and i%2==0 else 2 if (t%4!=1 or i%3==0) else 1 for t in range(T)]
            floor[-1]=2
            yield {'id':f'n{n}_{i:02d}','n':n,'load':load,'price':price,'floor':floor}

def lift_checks():
    checked=0
    for n in range(1,9):
        for cap in range(1,9):
            for rate in range(1,cap+1):
                for total in range(n*cap+1):
                    old=balanced(total,n); assert sum(old)==total and min(old)>=0 and max(old)<=cap
                    for tp in range(max(0,total-n*rate),min(n*cap,total+n*rate)+1):
                        new=balanced(tp,n); assert sum(new)==tp and min(new)>=0 and max(new)<=cap
                        dif=[b-a for a,b in zip(old,new)]; assert max(map(abs,dif))<=rate
                        assert sum(map(abs,dif))==abs(tp-total)
                        checked+=1
    return checked

def counterexamples():
    def max_total_after(state,capacity,rate):
        return sum(min(capacity,x+rate) for x in state)
    unbalanced=[0,4]; balanced_pair=[2,2]
    assert sum(unbalanced)==sum(balanced_pair)==4
    assert max_total_after(unbalanced,4,2)==6 and max_total_after(balanced_pair,4,2)==8
    # Distinct reserve and flex: same aggregate energy, different maximum discharge.
    # Flex rate 2, reserve rate 1, reserve floor 2.
    def max_discharge(f,r): return min(f,2)+min(r-2,1)
    assert max_discharge(2,2)==2 and max_discharge(0,4)==1
    # Ramp state cannot be dropped even when all other states coincide.
    assert abs(5-1)>2 and abs(5-5)<=2
    return {'unbalanced_initial_soc':{'states':[unbalanced,balanced_pair],'same_total':4,'max_next_totals':[6,8]},'distinct_reserve_floor':{'states':[[2,2],[0,4]],'same_total':4,'max_discharge':[2,1]},'omitted_previous_import':{'previous_import':[1,5],'candidate_import':5,'ramp_limit':2,'feasible':[False,True]}}

def main():
    results=[]
    for case in generate():
        r={m:dp(case,m) for m in ('labeled','quotient','aggregate')}
        m=independent_milp(case); costs=[v['cost'] for v in r.values()]
        assert costs[0]==costs[1]==costs[2],(case,costs)
        assert (m['status']==2 and costs[0] is None) or (m['status']==0 and abs(m['cost']-costs[0])<1e-6 and abs(m['dual_bound']-costs[0])<1e-6),(case,r,m)
        results.append({'case':case,'methods':r,'milp':m})
    summary={}
    for n in (2,3,'all'):
        rr=[x for x in results if n=='all' or x['case']['n']==n]
        a={m:{k:sum(x['methods'][m][k] for x in rr) for k in ('checks','expanded','seconds')} for m in ('labeled','quotient','aggregate')}
        summary[str(n)]={'cases':len(rr),'feasible':sum(x['methods']['labeled']['cost'] is not None for x in rr),'methods':a,'milp_seconds':sum(x['milp']['seconds'] for x in rr),'aggregate_check_reduction':1-a['aggregate']['checks']/a['labeled']['checks']}
    print(json.dumps({'seed':20261124,'python':platform.python_version(),'scipy':scipy.__version__,'parameters':{'flex_capacity':C,'flex_rate':R,'reserve_capacity':CR,'reserve_rate':RR,'max_import':GMAX,'ramp':RAMP,'initial_import':INIT_G,'flex_wear':FLEX_CYCLE,'reserve_wear':RES_CYCLE},'lift_transitions_checked':lift_checks(),'counterexamples':counterexamples(),'summary':summary,'runs':results},indent=2))
if __name__=='__main__': main()
