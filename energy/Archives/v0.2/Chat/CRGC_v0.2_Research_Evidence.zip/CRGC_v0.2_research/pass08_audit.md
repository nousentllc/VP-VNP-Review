# VP/VNP review: Pass 8 — curvature and extension interfaces

Date: 2026-11-24. Internal conditional audit, not independent proof of the separation.

## Source pin

- Claude (Anthropic), *VP ≠ VNP over every field*, 70-page manuscript, release commit `11b6c7e3c927df2658f513b6b68ea7f8929c62c5`.
- SHA-256 of the local PDF: `882f5eefb1e067cc8c99ddfe660c10d1d67f9fcee7b69364bd0bab06c0c1f97c` (recomputed this session).
- Original supplied archive: `VP_VNP_Review_2026-11-24_pass06.zip`. The prior archive and source pin are preserved, not replaced. This package does not redistribute the third-party manuscript or Lean subtree.
- Source: https://github.com/anthropics/formal-math/tree/11b6c7e3c927df2658f513b6b68ea7f8929c62c5/vp-vnp

## Obligation register

| Claim | Source / formal interface | Status | Next proof obligation |
|---|---|---|---|
| A.7 spectral extension | pp. 21–22; Paper/Extension.lean, prop_extend_cover, prop_extend_lower, prop_extend_gauge, prop_extend_localize, prop_extend | Reconstructed upper-functional equality and localized witness argument, conditional on cover and gauge semantics | Audit A.5 and tensor-cover semantics, including exact tensor restriction and zero cases |
| A.8 random price extension | pp. 21–22 | Read at the interface; not independently reconstructed in full | Check finite-to-infinite compactness and preservation of every old distance |
| B.2 crossing inequality | pp. 24–25; Paper/Crossing.lean | Used as stated | Independently reconstruct B.1 symbol counts, B.2 cover identity and B.3 limiting spectral application |
| C.2 parallelogram law | pp. 26–27; Paper/Means.lean, lem_means_parallelogram_le, lem_means | Reconstructed averaging, telescoping, homogeneity and limit direction; conditional on B.2 | Reconstruct remaining mean estimates and check full formal encoding |
| C.1 curvature | pp. 25–28; Paper/Fan.lean, thm_cn_iv, thm_cn_end, thm_cn | Reconstructed pointwise fourth-direction bound with explicit uniform remainder; traced other three estimates and final ordered limits | Audit construction from A.8 and finite-to-ultrafilter implementation in detail |
| C.3 completion | pp. 28–29; Paper/Curvature.lean, prop_space_step, prop_space_midpoints, prop_space_cauchy, prop_space_completion, prop_space | Reconstructed midpoint equality, zero-distance quotient, Cauchy completion and limit CN | Independent formal replay; C.1 and A.8 remain dependencies |
| D.2 | pp. 30–31; Paper/Alternative.lean | Pass 7 combinatorial checks rerun, exact JSON match | Resolve upstream obligations before declaring proof fully audited |

The detailed derivations are in Appendix A of the v0.2 master. In particular, with `M0 = D + d(z,m)`, the fourth-direction remainder is bounded by `4 A S^2 theta^2 D M0` before dividing by `S^2`. The limit order is fixed `A,S,T`, then `n→∞`, take the infimum in `S`, then `A→∞` for fixed `T`, finally `T→∞`. The finite script checks the telescope, the rational pointwise remainder and Euclidean midpoint equality. An l-infinity midpoint counterexample shows that arbitrary metrics with midpoints need not satisfy CN. There was no fresh Lean compilation in Pass 8.

OpenAI's formalization scope note was independently located: https://github.com/openai/math/blob/main/lean/docs/379.md. It distinguishes exact circuit separation from the stronger border-circuit rate stated in the manuscript. A full comparative audit is outstanding.
