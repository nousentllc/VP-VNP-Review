"""CRGC E003: homothetic exactness, heterogeneous inner restriction, LP lower bound.
All cases synthetic, one-hour intervals. Python >=3.10, numpy, scipy (HiGHS).
Run: python experiment_003.py > experiment_003_results.json
The full and restricted optimization models use the same prefix-SOC formulation;
physical schedule validation is separately implemented. Solver bounds are numerical.
"""
import json, platform, random, time, math
import numpy as np
import scipy
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

SEED=2026112403
TOL=2e-6

def solve(case,groups,relax=False,mode_groups=None):
    start=time.perf_counter(); assets=case['assets']; H=len(case['load']); K=len(groups)
    zmap=list(range(K)) if mode_groups is None else mode_groups
    J=max(zmap)+1; M=(2*K+J)*H+H; obj=np.zeros(M); lo=np.zeros(M); hi=np.full(M,np.inf); integer=np.zeros(M,int)
    def ix(k,t,j): return (k*H+t)*2+j if j<2 else 2*K*H+zmap[k]*H+t
    def gi(t): return (2*K+J)*H+t
    rows=[]; lower=[]; upper=[]
    def add(d,l=-np.inf,u=np.inf): rows.append(d);lower.append(l);upper.append(u)
    group_of={i:k for k,group in enumerate(groups) for i in group}
    weights={i:assets[i]['capacity']/sum(assets[j]['capacity'] for j in groups[group_of[i]]) for i in range(len(assets))}
    for k,group in enumerate(groups):
        chmax=min(assets[i]['charge_max']/weights[i] for i in group)
        dismax=min(assets[i]['discharge_max']/weights[i] for i in group)
        cost=sum(weights[i]*assets[i]['wear'] for i in group)
        for t in range(H):
            c,d,z=[ix(k,t,j) for j in range(3)];hi[c]=chmax;hi[d]=dismax;hi[z]=1;integer[z]=0 if relax else 1
            obj[c]=obj[d]=cost
            add({c:1,z:-chmax},u=0);add({d:1,z:dismax},u=dismax)
    # Each original asset retains its individual SOC bounds, efficiencies and terminal target.
    for i,a in enumerate(assets):
        k=group_of[i]; w=weights[i]; prefix={}
        for t in range(H):
            prefix[ix(k,t,0)]=w*a['eta_c'];prefix[ix(k,t,1)]=-w/a['eta_d']
            lower_s=a['floor'][t]-a['initial'];upper_s=a['capacity']-a['initial']
            if t==H-1: lower_s=upper_s=a['terminal']-a['initial']
            add(dict(prefix),lower_s,upper_s)
    # Optional exact-experiment domain: all assets in each true class use common mode.
    if case['common_mode']:
        for cls in sorted(set(a['class'] for a in assets)):
            ks=sorted({group_of[i] for i,a in enumerate(assets) if a['class']==cls})
            for k in ks[1:]:
                for t in range(H):
                    if ix(k,t,2)!=ix(ks[0],t,2): add({ix(k,t,2):1,ix(ks[0],t,2):-1},0,0)
    for t in range(H):
        g=gi(t);lo[g]=case['gmin'][t];hi[g]=case['gmax'][t];obj[g]=case['price'][t]
        d={g:1}
        for k in range(K): d[ix(k,t,0)]=-1;d[ix(k,t,1)]=1
        add(d,case['load'][t],case['load'][t]);r=case['ramp']
        if t: add({g:1,gi(t-1):-1},-r,r)
        else: add({g:1},case['g0']-r,case['g0']+r)
    ii=[];jj=[];vv=[]
    for r,d in enumerate(rows):
        for j,v in d.items(): ii.append(r);jj.append(j);vv.append(v)
    A=coo_matrix((vv,(ii,jj)),shape=(len(rows),M)).tocsc()
    build=time.perf_counter()-start
    result=milp(obj,integrality=integer,bounds=Bounds(lo,hi),constraints=LinearConstraint(A,lower,upper),options={'time_limit':20.,'mip_rel_gap':1e-9})
    out={'status':int(result.status),'message':str(result.message),'variables':M,'binary_variables':int(integer.sum()),'rows':len(rows),'nnz':A.nnz,'build_seconds':build,'solve_seconds':time.perf_counter()-start-build}
    if result.status!=0: return out
    out.update(cost=float(result.fun),mip_gap=None if relax else float(result.mip_gap),dual_bound=None if relax else float(result.mip_dual_bound))
    if not relax:
        x=result.x;g=[float(x[gi(t)]) for t in range(H)]
        ch=[[float(x[ix(group_of[i],t,0)]*weights[i]) for t in range(H)] for i in range(len(assets))]
        dis=[[float(x[ix(group_of[i],t,1)]*weights[i]) for t in range(H)] for i in range(len(assets))]
        out['path']={'g':g,'charge':ch,'discharge':dis}
        out['max_violation']=validate(case,out['path'],out['cost'])
        # Independently validate any additional shared-mode restrictions.
        for j in range(J):
            members=[i for i in range(len(assets)) if zmap[group_of[i]]==j]
            for t in range(H): assert min(sum(ch[i][t] for i in members),sum(dis[i][t] for i in members))<TOL
    return out

def validate(case,path,expected):
    g,c,d=path['g'],path['charge'],path['discharge'];assets=case['assets'];H=len(g);maxerr=0.;cost=0.;s=[a['initial'] for a in assets];prev=case['g0']
    def check(*args):
        nonlocal maxerr
        maxerr=max(maxerr,0.,*args)
    for t in range(H):
        net=case['load'][t]
        for i,a in enumerate(assets):
            u,v=c[i][t],d[i][t];net+=u-v;s[i]+=a['eta_c']*u-v/a['eta_d']
            check(-u,-v,u-a['charge_max'],v-a['discharge_max'],min(u,v),a['floor'][t]-s[i],s[i]-a['capacity'])
            cost+=a['wear']*(u+v)
        if case['common_mode']:
            for cls in set(a['class'] for a in assets):
                ids=[i for i,a in enumerate(assets) if a['class']==cls]
                check(min(sum(c[i][t] for i in ids),sum(d[i][t] for i in ids)))
        check(abs(net-g[t]),case['gmin'][t]-g[t],g[t]-case['gmax'][t],abs(g[t]-prev)-case['ramp'])
        cost+=g[t]*case['price'][t];prev=g[t]
    for i,a in enumerate(assets): check(abs(s[i]-a['terminal']))
    check(abs(cost-expected))
    assert maxerr<TOL,(case['id'],maxerr)
    return maxerr

def make_case(rng,kind,j):
    H=8;n=4;load=[float(rng.choice([3,4,5]))];ramp=2.
    for t in range(1,H): load.append(float(max(3,min(7,load[-1]+rng.choice([-2,-1,0,1,2])))))
    price=[float(rng.choice([4,8,20,45,75,105])) for _ in range(H)]
    if j%3==0: price[rng.randrange(H)]=-25.
    assets=[]
    for i in range(n):
        cls=i//2;cap=float([2,4,3,5][i]);ec=[.92,.84][cls];ed=[.9,.88][cls];wear=[1.0,2.8][cls]
        rate=[.5,.35][cls];init=.55;floor=[.1 if cls==0 else (.3 if t in (2,3,4) else .2) for t in range(H)]
        if kind=='heterogeneous':
            ec+=rng.uniform(-.07,.035);ed+=rng.uniform(-.05,.04);wear*=rng.uniform(.6,1.6);rate*=rng.uniform(.7,1.25);init+=rng.uniform(-.12,.12)
            floor=[max(.05,min(init-.04,q+rng.uniform(-.07,.07))) for q in floor]
        assets.append({'class':cls,'capacity':cap,'charge_max':rate*cap,'discharge_max':rate*cap*.8,'eta_c':ec,'eta_d':ed,'wear':wear,'initial':init*cap,'terminal':init*cap,'floor':[q*cap for q in floor]})
    return {'id':f'{kind}_{j:02}','kind':kind,'assets':assets,'load':load,'price':price,'gmin':[0.]*H,'gmax':[9.]*H,'g0':load[0],'ramp':ramp,'common_mode':kind=='homothetic'}

def counterexample():
    # Both units must return to initial SOC; a charge/discharge pair absorbs 0.36 per hour.
    # If a shared mode forbids opposing actions, both periods must charge and cannot return SOC.
    a={'class':0,'capacity':3.,'charge_max':1.,'discharge_max':1.,'eta_c':.8,'eta_d':.8,'wear':.1,'initial':1.5,'terminal':1.5,'floor':[0.,0.]}
    c={'id':'opposing_mode_required','kind':'counterexample','assets':[dict(a),dict(a)],'load':[0.,0.],'price':[1.,1.],'gmin':[.36,.36],'gmax':[.36,.36],'g0':.36,'ramp':0.,'common_mode':False}
    f=solve(c,[[0],[1]]);q=solve(c,[[0,1]]);m=solve(c,[[0],[1]],mode_groups=[0,0]);lp=solve(c,[[0],[1]],relax=True)
    assert f['status']==0 and q['status']==2 and m['status']==2 and lp['status']==0,(f,q,m,lp)
    return {'case':c,'full':f,'one_group':q,'shared_mode':m,'lp':lp}

def main():
    rng=random.Random(SEED);runs=[]
    for kind in ('homothetic','heterogeneous'):
        for j in range(12):
            c=make_case(rng,kind,j);full=solve(c,[[i] for i in range(4)]);cluster=solve(c,[[0,1],[2,3]]);single=solve(c,[[0,1,2,3]]);lp=solve(c,[[i] for i in range(4)],relax=True);mode=solve(c,[[i] for i in range(4)],mode_groups=[0,0,1,1])
            assert all(x['status']==0 for x in (full,cluster,single,lp,mode)),(c['id'],full['status'],cluster['status'],single['status'],lp['status'])
            assert lp['cost']<=full['cost']+TOL and full['cost']<=mode['cost']+TOL and mode['cost']<=cluster['cost']+TOL and cluster['cost']<=single['cost']+TOL
            if kind=='homothetic': assert abs(full['cost']-cluster['cost'])<TOL
            runs.append({'case':c,'full':full,'cluster':cluster,'single':single,'lp':lp,'mode':mode,'mode_regret':max(0.,mode['cost']-full['cost']),'mode_bound_width':max(0.,mode['cost']-lp['cost']),'cluster_regret':max(0.,cluster['cost']-full['cost']),'lp_bound_width':max(0.,cluster['cost']-lp['cost']),'single_regret':max(0.,single['cost']-full['cost'])})
    summary={}
    for kind in ('homothetic','heterogeneous'):
        rs=[r for r in runs if r['case']['kind']==kind];summary[kind]={'cases':len(rs),'mode_exact':sum(r['mode_regret']<TOL for r in rs),'mode_regret_mean':float(np.mean([r['mode_regret'] for r in rs])),'mode_regret_max':max(r['mode_regret'] for r in rs),'mode_bound_max':max(r['mode_bound_width'] for r in rs),'cluster_exact':sum(r['cluster_regret']<TOL for r in rs),'cluster_regret_mean':float(np.mean([r['cluster_regret'] for r in rs])),'cluster_regret_max':max(r['cluster_regret'] for r in rs),'lp_bound_mean':float(np.mean([r['lp_bound_width'] for r in rs])),'lp_bound_max':max(r['lp_bound_width'] for r in rs),'single_regret_mean':float(np.mean([r['single_regret'] for r in rs])),'single_regret_max':max(r['single_regret'] for r in rs),'max_lift_violation':max(r[m]['max_violation'] for r in rs for m in ('full','cluster','single','mode')),'formulations':{m:{'vars':rs[0][m]['variables'],'binaries':rs[0][m]['binary_variables'],'rows':rs[0][m]['rows'],'mean_build_plus_solve_seconds':float(np.mean([r[m]['build_seconds']+r[m]['solve_seconds'] for r in rs]))} for m in ('full','cluster','single','mode','lp')}}
    print(json.dumps({'seed':SEED,'python':platform.python_version(),'scipy':scipy.__version__,'tolerance':TOL,'summary':summary,'counterexample':counterexample(),'runs':runs},indent=2))
if __name__=='__main__': main()
