"""Finite checks of D.2's rank marginals and exchange connectivity over F2.
Not a proof that rank-distance is a price, not a Lean kernel check.
Run: python pass07_checks.py > pass07_checks.json
"""
import itertools,json
from collections import Counter

def rank(x,n):
    rows=[(x>>(i*n))&((1<<n)-1) for i in range(n)]; r=0
    for j in range(n):
        k=next((k for k in range(r,n) if rows[k]>>j&1),None)
        if k is None: continue
        rows[r],rows[k]=rows[k],rows[r]
        for k in range(r+1,n):
            if rows[k]>>j&1: rows[k]^=rows[r]
        r+=1
    return r

def span(vs):
    s={0}
    for v in vs: s|={x^v for x in s}
    return s

def subspace_connectivity(n,U):
    outside=set(range(1<<n))-U
    neighbors={x:{z for z in outside if z not in {x^u for u in U}} for x in outside}
    visited=set(); todo=[next(iter(outside))]
    while todo:
        x=todo.pop()
        if x in visited:continue
        visited.add(x);todo.extend(neighbors[x]-visited)
    return len(visited),len(outside)

def main():
    n=3; M=range(1<<(n*n)); ranks={x:rank(x,n) for x in M}; rc=Counter(ranks.values()); buckets={r:[x for x in M if ranks[x]==r] for r in range(n+1)}
    # rank(W+W')=rank W+rank W' iff both row and column spaces independent.
    marg=[]
    for i in range(1,n):
        for j in range(1,n-i+1):
            pairs=[(x,y) for x in buckets[i] for y in buckets[j] if ranks[x^y]==i+j]
            a,b,c=(Counter(z) for z in ([x for x,y in pairs],[y for x,y in pairs],[x^y for x,y in pairs]))
            assert len(a)==rc[i] and len(set(a.values()))==1 and len(b)==rc[j] and len(set(b.values()))==1 and len(c)==rc[i+j] and len(set(c.values()))==1
            marg.append({'ranks':[i,j],'ordered_pairs':len(pairs),'first_multiplicity':next(iter(a.values())),'second_multiplicity':next(iter(b.values())),'sum_multiplicity':next(iter(c.values()))})
    # Any two rank-one matrices are both transversal to a third.
    adj={x:{y for y in buckets[1] if ranks[x^y]==2} for x in buckets[1]}
    checked=0; least=100000
    for x in buckets[1]:
        for y in buckets[1]:
            count=len(adj[x]&adj[y]); assert count>0;least=min(least,count);checked+=1
    con=[]
    for n in (2,3,4,5):
        for d in range(n-1):
            U=set(range(1<<d)); a,b=subspace_connectivity(n,U);assert a==b
            con.append({'dimension':n,'subspace_dim':d,'connected_vertices':a})
    # Boundary failure quotient dimension 1: outside has 2^d isolated nodes.
    a,b=subspace_connectivity(2,{0,1}); assert a==1 and b==2
    # Verify characteristic-2 exchange as a matrix identity, for all independent u1,u2 and x1,x2 in F2^3.
    def outer(u,x): return sum((x<<(i*3)) for i in range(3) if u>>i&1)
    vec=list(range(1,8)); exchange=0
    for u,v,x,y in itertools.product(vec,repeat=4):
        if u==v or x==y:continue
        assert outer(u,x)^outer(v,y)==outer(u,x^y)^outer(u^v,y)
        exchange+=1
    print(json.dumps({'dimension_3_rank_counts':dict(rc),'marginals':marg,'rank_one_pairs_common_third_checked':checked,'minimum_common_thirds':least,'connectivity':con,'dimension_2_rank_one_quotient_boundary':{'component':a,'outside':b},'exchange_identities_checked':exchange,'limitations':'Finite combinatorial checks only. They do not establish spectral realizability or CAT(0) embedding.'},indent=2))
if __name__=='__main__':main()
