# CRGC v0.2 — reproducibility package

Internal development checkpoint, 2026-11-24. Companion to the standalone `CRGC_Whitepaper_v0.2.tex` and compiled PDF. This archive contains the runnable finite checks, seeded synthetic experiments, outputs, pass audit and source hashes. Version 0.1 is unchanged.

## Replay

Use Python 3.10+ (the recorded runs used Python 3.13.5), NumPy and SciPy 1.17.0 (HiGHS). Install `requirements.txt` in a fresh virtual environment where supported. Pass 7 and 8 scripts use only the standard library. From this directory:

```sh
python pass07_checks.py > replay_pass07.json
python pass08_checks.py > replay_pass08.json
python experiment_002.py > replay_experiment_002.json
python experiment_003.py > replay_experiment_003.json
```

Recorded JSON contains all seeded E002/E003 case data and individual schedules. E002 was rerun in this session: all 24 aggregate objectives and aggregate/labeled candidate transition counts matched the earlier archived result. Pass 7 JSON matched exactly. Wall time is machine- and run-dependent. E003 uses solver-reported numerical optimum and LP bounds with explicit tolerances, not exact proof certificates. The full and reduced E003 optimization models share one builder, while the schedule validator independently recomputes feasibility and objective; independent solver implementation and external replication remain open.

## Findings and restrictions

- E002: aggregate DP checks 255,440 vs. labeled DP 5,399,145, 95.27% reduction; all 24 sampled objectives matched the independent MILP and lift checks. Not an industrial solver speedup.
- E003: 12 homothetic common-mode cases and 12 heterogeneous cases with unrestricted individual full-model modes, plus a forced opposing-mode stress case. Shared mode with asset-level powers matches all sampled full optima. Fixed proportional control is inferior in all heterogeneous cases; disparate round-trip efficiencies and exact cyclic endpoints force zero shared throughput. Sharing modes is also infeasible in the opposing-mode stress case. Every development case has a feasible no-action baseline; no holdout or field tests were run.
- Pass 8: the finite integer/rational checks are not a proof of spectral realizability or of the VP/VNP theorem. The full Lean build, A.5 and B.2–B.3 review remain open. No new Lean compilation.
- E001 is described in earlier conversation only; original code/inputs were not available for replay, so its numerical claims are excluded from this evidence checkpoint.

## Claim-to-evidence map

| Claim | Evidence | Status / limit |
|---|---|---|
| Anthropic exact lower-bound statement | pinned manuscript and previous six-pass archive | Claimed theorem; partial internal review |
| D.2 combinatorial identities | pass07_checks.py/json | Replayed finite tests |
| C.1/C.2/C.3 algebraic interfaces | pass08_audit.md, pass08_checks.py/json, master Appendix A | Conditional derivations and finite checks |
| Exact balanced lift | master Section 6.1; E002 code | Proved under specified assumptions; finite tests |
| Homothetic common-mode reduction | master Section 6.2; E003 code | Derived and sampled; not unrestricted-mode exactness |
| Unequal efficiency obstruction | master Section 6.3; E003 heterogeneous cases | Derived under exact cyclic endpoint and fixed proportional power assumptions |
| Shared-mode candidate feasible and zero numerical regret on sampled cases | E003 output and validator | Development sample, LP bound tight throughout; counterexample to universal exactness |
| Real-world grid cost or capacity impact | none | Unestablished; no dollar extrapolation |
| Novelty vs. comprehensive prior art | targeted literature only | Unestablished |

## Integrity

`SHA256SUMS` records package files. The supplied proof archive retains its own `source-lock.json`; we did not edit or redistribute it. The v0.2 manuscript is self-contained and can be compiled with `pdflatex` twice (or until references stabilize). No external images or BibTeX file are required.
